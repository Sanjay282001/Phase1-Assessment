package project;

import java.io.File;
import java.util.Scanner;

public class DelFile {
	void delete() {
	String path="D:\\project\\";
	Scanner sc=new Scanner(System.in);
	System.out.println("enter the filename to delete");
	String filename=sc.next();
	String finalpath=path+filename;
	File f=new File(finalpath);
	if(f.exists()) {
		f.delete();
		System.out.println("file gets deleted");
	}
	else {
		System.out.println("file is not found");
	}
	}

}
