package project;

import java.io.IOException;
import java.util.Scanner;

public class Maincase {
	public static void main(String[] args) throws IOException {
		Scanner sc=new Scanner(System.in);
		AddFile a=new AddFile();
		DelFile d=new DelFile();
		SearFile s=new SearFile();
		Dispfile dis=new Dispfile();
		System.out.println("_______________Application______________");
		System.out.println("Enter 1:To Retrieve the file");
		System.out.println("Enter 2:Business-level operations:");
		System.out.println("Enter 3:Close the application");
		System.out.println("Enter the choice:");
		int choice=sc.nextInt();
			switch(choice) {
				case 1:
					dis.diplay();
					break;
				case 2:
					System.out.println("Business-level operations:");
					System.out.println("Enter 1:Add file ");
					System.out.println("Enter 2:delete the file");
					System.out.println("Enter 3:search the file ");
					System.out.println("Enter 4:To exit");
					System.out.println("enter the operation:");
					int ch=sc.nextInt();
					switch(ch){
						case 1:
							a.addfile();
							break;
						case 2:
							d.delete();
							break;
						case 3:
							s.search();
							break;
						case 4:
							System.exit(0);
							break;
						default:
							System.out.println("enter the valid operation");
							break;	
					}
					break;
				case 3:
					System.out.println("Application closed sucessfully");
					System.exit(0);
					break;
				default:
					System.out.println("enter the valid operation");
					System.exit(0);
					break;
			}
	}
}
