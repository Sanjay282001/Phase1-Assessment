package project;

import java.io.File;
import java.io.IOException;

class Dispfile {
	void diplay() throws IOException{
		String path="D:\\project\\";
		System.out.println("displaying file name filename");
		File f=new File(path);
		//display
		File filenames[]=f.listFiles();
		for(File ff:filenames) {
			System.out.println(ff.getName());
		}
	}
	
}
